# NeoChat
Chrome extension for handling neomail

This extension was written because I was always having trouble remembering what I wrote to users or trying to make sense out of a response, especially when receiving a lot per day or getting a late reply.

What it does is store messages you read and send in your computer and display them in a nice chat-like interface where you can view the messages you exchanged in the past with a user.

To access the chat, just go to your neomail and click on the neo chat link next to Neogreetings. To load messages there, just read your neo mails as usual and they will be automatically added.

The extension does not automate any player activity, or provide data that would otherwise be inaccessible; it only helps to facilitate better searching, sorting, and organisation of your neomails.

This software is not endorsed by or affliated with Neopets.
